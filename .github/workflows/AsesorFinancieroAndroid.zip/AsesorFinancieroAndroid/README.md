# Mi Asesor Financiero — Android (MVP offline)

Aplicación Android nativa en Kotlin + Jetpack Compose. Los movimientos, deudas y metas se guardan localmente en Room/SQLite. No requiere cuenta, servidor ni conexión a internet para las funciones incluidas.

## Incluye
- Resumen mensual de ingresos, gastos y flujo neto.
- Registro y eliminación de ingresos y gastos.
- Registro de deudas con saldo, tasa mensual y cuota.
- Estimación de meses para pagar cada deuda (si la cuota cubre los intereses).
- Metas de ahorro y aporte mensual sugerido.
- Proyecciones simples a 6 y 12 meses.
- Tema oscuro negro/verde.
- Datos almacenados en el dispositivo.

## Requisitos
- Android Studio reciente o un entorno Android que admita proyectos Gradle modernos.
- JDK 17.
- Android SDK 35.
- Gradle 8.9 (el entorno de compilación de GitHub Actions instala Gradle; no se incluye el wrapper en este ZIP).

## Compilar APK desde un celular Android sin PC
La ruta más confiable es compilar en la nube con GitHub Actions usando el navegador del teléfono:

1. Crea una cuenta en https://github.com si no tienes una.
2. Crea un repositorio nuevo y privado llamado `asesor-financiero-android`.
3. Sube todos los archivos de este ZIP conservando las carpetas.
4. Abre la pestaña **Actions** del repositorio y permite GitHub Actions si lo solicita.
5. En **Actions**, ejecuta el flujo **Build Android APK** (Run workflow). Si no aparece, confirma que `.github/workflows/android-apk.yml` se subió correctamente.
6. Cuando termine en verde, abre la ejecución y descarga el artefacto `asesor-financiero-debug-apk`.
7. Descomprime el artefacto descargado y abre `app-debug.apk` en el teléfono. Android puede pedir autorización para instalar desde esa fuente.

También puedes abrir el proyecto en Android Studio si tienes acceso a un computador.

## Seguridad y privacidad
- La base de datos es local y no sincroniza datos.
- Desinstalar la app o borrar sus datos puede eliminar el historial. Exportación/restauración no está incluida aún.
- El APK debug es para pruebas personales, no para publicar en Play Store.
- La IA por API NO está incluida en esta versión offline. Para añadirla después, se necesita conexión a internet y una API key; no guardes una clave secreta directamente dentro de un APK distribuido.
- Esta app es una herramienta de organización y proyección, no asesoría financiera profesional.

## Limitaciones del MVP
- El resumen de mes utiliza el mes actual.
- Las proyecciones son aproximaciones y dependen de los datos registrados.
- La proyección global de deudas a 12 meses es simplificada y no modela todos los calendarios de amortización.
- No incluye recordatorios del sistema, exportación CSV ni copia de seguridad en la nube todavía.

## Estructura
- `app/src/main/java/.../MainActivity.kt`: interfaz y lógica de la primera versión.
- `app/src/main/java/.../data/FinanceData.kt`: entidades, DAO y base de datos Room.
- `.github/workflows/android-apk.yml`: compilación automática de APK.
