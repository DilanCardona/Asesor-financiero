package com.tuapp.asesorfinanciero

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.tuapp.asesorfinanciero.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

private val Bg = Color(0xFF07110F)
private val Panel = Color(0xFF10231F)
private val Green = Color(0xFF49E6A0)
private val Mint = Color(0xFFB5F7D9)
private val TextMain = Color(0xFFEAF8F1)
private val Muted = Color(0xFF9BB8AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = FinanceDatabase.get(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green,
                    onPrimary = Color(0xFF002116),
                    background = Bg,
                    surface = Panel,
                    onSurface = TextMain,
                    secondary = Mint
                )
            ) {
                FinanceApp(db.financeDao())
            }
        }
    }
}

private fun cop(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("es", "CO")).apply {
        maximumFractionDigits = 0
        minimumFractionDigits = 0
    }.format(value)

private fun monthRange(): Pair<Long, Long> {
    val cal = Calendar.getInstance()
    cal.set(Calendar.DAY_OF_MONTH, 1)
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val start = cal.timeInMillis
    cal.add(Calendar.MONTH, 1)
    return start to cal.timeInMillis
}

@Composable
private fun FinanceApp(dao: FinanceDao) {
    var tab by remember { mutableIntStateOf(0) }
    var showAddMovement by remember { mutableStateOf(false) }
    var showAddDebt by remember { mutableStateOf(false) }
    var showAddGoal by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val movements by dao.movements().collectAsState(initial = emptyList())
    val debts by dao.debts().collectAsState(initial = emptyList())
    val goals by dao.goals().collectAsState(initial = emptyList())
    val month = remember { monthRange() }
    val thisMonth by dao.movementsBetween(month.first, month.second).collectAsState(initial = emptyList())

    val income = thisMonth.filter { it.kind == "INGRESO" }.sumOf { it.amount }
    val expenses = thisMonth.filter { it.kind == "GASTO" }.sumOf { it.amount }
    val net = income - expenses

    Scaffold(
        containerColor = Bg,
        topBar = {
            Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text("TU ASESOR", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Financiero", color = TextMain, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Tus finanzas, bajo control.", color = Muted, fontSize = 13.sp)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = TextMain) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Inicio") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.AttachMoney, null) }, label = { Text("Movimientos") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.CreditCard, null) }, label = { Text("Deudas") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Savings, null) }, label = { Text("Ahorro") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Proyección") })
            }
        },
        floatingActionButton = {
            when (tab) {
                1 -> FloatingActionButton(onClick = { showAddMovement = true }, containerColor = Green, contentColor = Bg) { Icon(Icons.Default.Add, "Agregar movimiento") }
                2 -> FloatingActionButton(onClick = { showAddDebt = true }, containerColor = Green, contentColor = Bg) { Icon(Icons.Default.Add, "Agregar deuda") }
                3 -> FloatingActionButton(onClick = { showAddGoal = true }, containerColor = Green, contentColor = Bg) { Icon(Icons.Default.Add, "Agregar meta") }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(Modifier.padding(padding), income, expenses, net, debts.sumOf { it.balance }, goals, movements.take(5))
            1 -> MovementScreen(Modifier.padding(padding), movements, onDelete = { id -> scope.launch { dao.deleteMovement(id) } })
            2 -> DebtScreen(Modifier.padding(padding), debts, onDelete = { id -> scope.launch { dao.deleteDebt(id) } })
            3 -> GoalScreen(Modifier.padding(padding), goals, onDelete = { id -> scope.launch { dao.deleteGoal(id) } })
            else -> ProjectionScreen(Modifier.padding(padding), income, expenses, debts, goals)
        }
    }

    if (showAddMovement) AddMovementDialog(
        onDismiss = { showAddMovement = false },
        onSave = { kind, category, amount, note ->
            scope.launch { dao.addMovement(Movement(kind = kind, category = category, amount = amount, note = note)) }
            showAddMovement = false
        }
    )
    if (showAddDebt) AddDebtDialog(
        onDismiss = { showAddDebt = false },
        onSave = { name, balance, rate, payment ->
            scope.launch { dao.addDebt(Debt(name = name, balance = balance, monthlyRatePercent = rate, monthlyPayment = payment)) }
            showAddDebt = false
        }
    )
    if (showAddGoal) AddGoalDialog(
        onDismiss = { showAddGoal = false },
        onSave = { name, target, saved, months ->
            val date = Calendar.getInstance().apply { add(Calendar.MONTH, months) }.timeInMillis
            scope.launch { dao.addGoal(SavingsGoal(name = name, targetAmount = target, savedAmount = saved, targetDateMillis = date)) }
            showAddGoal = false
        }
    )
}

@Composable
private fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp), content = content)
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Text(title, color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    if (subtitle != null) Text(subtitle, color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    income: Long,
    expenses: Long,
    net: Long,
    debtTotal: Long,
    goals: List<SavingsGoal>,
    latest: List<Movement>
) {
    Page(modifier) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("Tu resumen", "Este mes · valores en pesos colombianos")
        PanelCard {
            Text("Flujo neto del mes", color = Muted)
            Text(cop(net), color = if (net >= 0) Green else Color(0xFFFF8C8C), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniMetric("Ingresos", cop(income), Modifier.weight(1f), Green)
                MiniMetric("Gastos", cop(expenses), Modifier.weight(1f), Color(0xFFFF9B9B))
            }
        }
        PanelCard {
            Text("Deuda registrada", color = Muted)
            Text(cop(debtTotal), color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Registra tus saldos para ver un plan de pago.", color = Muted, fontSize = 12.sp)
        }
        SectionTitle("Metas de ahorro")
        if (goals.isEmpty()) EmptyHint("Agrega una meta en la pestaña Ahorro.")
        goals.take(2).forEach { goal ->
            val progress = if (goal.targetAmount > 0) (goal.savedAmount.toFloat() / goal.targetAmount).coerceIn(0f, 1f) else 0f
            PanelCard {
                Text(goal.name, fontWeight = FontWeight.SemiBold)
                Text("${cop(goal.savedAmount)} de ${cop(goal.targetAmount)}", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Green)
            }
        }
        SectionTitle("Movimientos recientes")
        if (latest.isEmpty()) EmptyHint("Aún no tienes movimientos. Pulsa Movimientos para agregar uno.")
        latest.forEach { item -> MovementRow(item, onDelete = {}) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun MiniMetric(label: String, amount: String, modifier: Modifier, color: Color) {
    Column(modifier.background(Bg, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(amount, color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun MovementScreen(modifier: Modifier, movements: List<Movement>, onDelete: (Long) -> Unit) {
    Page(modifier) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("Movimientos", "Registra cada ingreso y gasto.")
        if (movements.isEmpty()) EmptyHint("Pulsa + para registrar tu primer movimiento.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(movements, key = { it.id }) { item -> MovementRow(item) { onDelete(item.id) } }
        }
    }
}

@Composable
private fun MovementRow(item: Movement, onDelete: () -> Unit) {
    PanelCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.category, fontWeight = FontWeight.SemiBold, color = TextMain)
                if (item.note.isNotBlank()) Text(item.note, color = Muted, fontSize = 12.sp)
                Text(if (item.kind == "INGRESO") "Ingreso" else "Gasto", color = Muted, fontSize = 11.sp)
            }
            Text((if (item.kind == "INGRESO") "+" else "−") + cop(item.amount),
                color = if (item.kind == "INGRESO") Green else Color(0xFFFF9B9B), fontWeight = FontWeight.Bold)
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Eliminar", tint = Muted) }
        }
    }
}

@Composable
private fun DebtScreen(modifier: Modifier, debts: List<Debt>, onDelete: (Long) -> Unit) {
    Page(modifier) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("Mis deudas", "Saldo, interés y cuota mensual.")
        if (debts.isEmpty()) EmptyHint("Pulsa + para agregar una deuda.")
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(debts, key = { it.id }) { debt ->
                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(debt.name, fontWeight = FontWeight.Bold)
                            Text("Interés mensual: ${"%.2f".format(Locale.US, debt.monthlyRatePercent)}%", color = Muted, fontSize = 12.sp)
                            Text("Cuota: ${cop(debt.monthlyPayment)}", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { onDelete(debt.id) }) { Icon(Icons.Default.Delete, null, tint = Muted) }
                    }
                    Text(cop(debt.balance), color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    val months = monthsToPay(debt.balance, debt.monthlyRatePercent, debt.monthlyPayment)
                    Text(if (months == null) "Aumenta la cuota para amortizar esta deuda." else "Estimación: $months meses", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun GoalScreen(modifier: Modifier, goals: List<SavingsGoal>, onDelete: (Long) -> Unit) {
    Page(modifier) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("Ahorro y metas", "Define objetivos alcanzables.")
        if (goals.isEmpty()) EmptyHint("Pulsa + para crear una meta.")
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            items(goals, key = { it.id }) { goal ->
                val remaining = max(0L, goal.targetAmount - goal.savedAmount)
                val months = max(1, ((goal.targetDateMillis - System.currentTimeMillis()) / (30L * 24 * 60 * 60 * 1000)).toInt())
                val progress = if (goal.targetAmount > 0) (goal.savedAmount.toFloat() / goal.targetAmount).coerceIn(0f, 1f) else 0f
                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(goal.name, fontWeight = FontWeight.Bold)
                            Text("${cop(goal.savedAmount)} / ${cop(goal.targetAmount)}", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { onDelete(goal.id) }) { Icon(Icons.Default.Delete, null, tint = Muted) }
                    }
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Green)
                    Spacer(Modifier.height(8.dp))
                    Text("Ahorro sugerido: ${cop(ceil(remaining.toDouble() / months).toLong())} al mes", color = Green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun ProjectionScreen(modifier: Modifier, income: Long, expenses: Long, debts: List<Debt>, goals: List<SavingsGoal>) {
    Page(modifier) {
        Spacer(Modifier.height(4.dp))
        SectionTitle("Proyecciones", "Escenarios simples basados en tus registros.")
        PanelCard {
            Text("Si mantienes el resultado de este mes", color = Muted)
            Text("${cop(income - expenses)} / mes", color = Green, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("Proyección a 6 meses: ${cop((income - expenses) * 6)}", color = TextMain)
            Text("Es una simulación, no una garantía. Se basa solo en movimientos del mes actual.", color = Muted, fontSize = 12.sp)
        }
        PanelCard {
            Text("Escenario de deudas", fontWeight = FontWeight.Bold)
            Text("Saldo total: ${cop(debts.sumOf { it.balance })}", color = Green, fontSize = 22.sp)
            val monthlyPayments = debts.sumOf { it.monthlyPayment }
            Text("Cuotas mensuales registradas: ${cop(monthlyPayments)}", color = Muted)
            Text("Saldo aproximado en 12 meses sin intereses: ${cop(max(0L, debts.sumOf { it.balance } - monthlyPayments * 12))}", color = Muted, fontSize = 12.sp)
            Text("La proyección sin intereses es orientativa; el cálculo individual por deuda considera la tasa ingresada.", color = Muted, fontSize = 11.sp)
        }
        PanelCard {
            Text("Ahorro proyectado", fontWeight = FontWeight.Bold)
            val goalRemaining = goals.sumOf { max(0L, it.targetAmount - it.savedAmount) }
            Text("Te falta ahorrar en total: ${cop(goalRemaining)}", color = Green, fontSize = 20.sp)
            Text("Distribuye tus aportes según la fecha objetivo de cada meta.", color = Muted, fontSize = 12.sp)
        }
        PanelCard {
            Text("Siguiente recomendación", fontWeight = FontWeight.Bold)
            val monthlyPayments = debts.sumOf { it.monthlyPayment }
            val room = income - expenses - monthlyPayments
            Text(
                when {
                    income == 0L -> "Registra tus ingresos y gastos para crear una proyección más útil."
                    room < 0 -> "Tus gastos y cuotas superan tus ingresos registrados. Revisa primero los gastos variables y contacta a tus acreedores si no puedes cumplir los pagos."
                    room == 0L -> "Todo tu flujo neto está comprometido con cuotas. Evita asumir nuevas obligaciones hasta tener margen."
                    else -> "Tu margen estimado después de gastos y cuotas es ${cop(room)}. Reserva primero dinero para gastos esenciales e imprevistos."
                },
                color = TextMain
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

private fun monthsToPay(balance: Long, monthlyRatePercent: Double, payment: Long): Int? {
    if (balance <= 0) return 0
    if (payment <= 0) return null
    var remaining = balance.toDouble()
    val rate = monthlyRatePercent / 100.0
    if (rate > 0 && payment <= remaining * rate) return null
    var months = 0
    while (remaining > 0 && months < 1200) {
        remaining = remaining * (1 + rate) - payment
        months++
    }
    return if (remaining <= 0) months else null
}

@Composable
private fun EmptyHint(message: String) {
    Text(message, color = Muted, modifier = Modifier.padding(vertical = 12.dp))
}

@Composable
private fun AddMovementDialog(onDismiss: () -> Unit, onSave: (String, String, Long, String) -> Unit) {
    var kind by remember { mutableStateOf("GASTO") }
    var category by remember { mutableStateOf("Alimentación") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val categories = listOf("Alimentación", "Transporte", "Vivienda", "Servicios", "Salud", "Educación", "Entretenimiento", "Trabajo", "Otros")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo movimiento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == "INGRESO", onClick = { kind = "INGRESO" }, label = { Text("Ingreso") })
                    FilterChip(selected = kind == "GASTO", onClick = { kind = "GASTO" }, label = { Text("Gasto") })
                }
                Text("Categoría", color = Muted)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("Categoría") })
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
                    }
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("Valor en COP") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Nota (opcional)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { amount.toLongOrNull()?.takeIf { it > 0 }?.let { onSave(kind, category, it, note) } }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel
    )
}

@Composable
private fun AddDebtDialog(onDismiss: () -> Unit, onSave: (String, Long, Double, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var balance by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("0") }
    var payment by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agregar deuda") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true)
                OutlinedTextField(balance, { balance = it.filter(Char::isDigit) }, label = { Text("Saldo actual (COP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(rate, { rate = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.') }, label = { Text("Interés mensual (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(payment, { payment = it.filter(Char::isDigit) }, label = { Text("Cuota mensual (COP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { val b = balance.toLongOrNull(); val p = payment.toLongOrNull(); if (name.isNotBlank() && b != null && b > 0 && p != null && p >= 0) onSave(name, b, rate.toDoubleOrNull() ?: 0.0, p) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel
    )
}

@Composable
private fun AddGoalDialog(onDismiss: () -> Unit, onSave: (String, Long, Long, Int) -> Unit) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("0") }
    var months by remember { mutableStateOf("6") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crear meta de ahorro") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre de la meta") }, singleLine = true)
                OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Objetivo (COP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(saved, { saved = it.filter(Char::isDigit) }, label = { Text("Ya ahorrado (COP)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(months, { months = it.filter(Char::isDigit) }, label = { Text("Meses para cumplirla") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { val t = target.toLongOrNull(); val s = saved.toLongOrNull() ?: 0; val m = months.toIntOrNull(); if (name.isNotBlank() && t != null && t > 0 && m != null && m > 0) onSave(name, t, s, m) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel
    )
}
