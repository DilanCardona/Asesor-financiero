package com.tuapp.asesorfinanciero.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "movements")
data class Movement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // INGRESO or GASTO
    val category: String,
    val amount: Long, // COP, stored as whole pesos
    val note: String = "",
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val balance: Long,
    val monthlyRatePercent: Double = 0.0,
    val monthlyPayment: Long = 0,
    val dueDay: Int = 1
)

@Entity(tableName = "goals")
data class SavingsGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val targetAmount: Long,
    val savedAmount: Long = 0,
    val targetDateMillis: Long
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM movements ORDER BY dateMillis DESC")
    fun movements(): Flow<List<Movement>>

    @Query("SELECT * FROM movements WHERE dateMillis >= :start AND dateMillis < :end ORDER BY dateMillis DESC")
    fun movementsBetween(start: Long, end: Long): Flow<List<Movement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addMovement(item: Movement)

    @Query("DELETE FROM movements WHERE id = :id")
    suspend fun deleteMovement(id: Long)

    @Query("SELECT * FROM debts ORDER BY balance DESC")
    fun debts(): Flow<List<Debt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addDebt(item: Debt)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebt(id: Long)

    @Query("SELECT * FROM goals ORDER BY targetDateMillis ASC")
    fun goals(): Flow<List<SavingsGoal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addGoal(item: SavingsGoal)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)
}

@Database(entities = [Movement::class, Debt::class, SavingsGoal::class], version = 1, exportSchema = false)
abstract class FinanceDatabase : RoomDatabase() {
    abstract fun financeDao(): FinanceDao

    companion object {
        @Volatile private var INSTANCE: FinanceDatabase? = null
        fun get(context: Context): FinanceDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FinanceDatabase::class.java,
                    "finance-local.db"
                ).build().also { INSTANCE = it }
            }
    }
}
